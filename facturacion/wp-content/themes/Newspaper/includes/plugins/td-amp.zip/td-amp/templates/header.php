<?php
/**
 * Header template part.
 *
 */

$this->load_parts( array( 'header-bar' ) );
