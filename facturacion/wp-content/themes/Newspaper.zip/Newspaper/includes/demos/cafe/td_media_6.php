<?php
//menu summary images

td_demo_media::add_image_to_media_gallery('coffee',                   "http://demo_content.tagdiv.com/Newspaper_6/cafe/coffee.jpg");
td_demo_media::add_image_to_media_gallery('pastry',                   "http://demo_content.tagdiv.com/Newspaper_6/cafe/pastry.jpg");
td_demo_media::add_image_to_media_gallery('desserts',                 "http://demo_content.tagdiv.com/Newspaper_6/cafe/desserts.jpg");
td_demo_media::add_image_to_media_gallery('visit-menu',               "http://demo_content.tagdiv.com/Newspaper_6/cafe/visit-menu.jpg");
td_demo_media::add_image_to_media_gallery('td_footer_bg',             "http://demo_content.tagdiv.com/Newspaper_6/cafe/footer-bg.jpg");