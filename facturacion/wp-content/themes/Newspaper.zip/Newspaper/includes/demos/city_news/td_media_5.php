<?php

// ads

td_demo_media::add_image_to_media_gallery('td_city_header_ad',                  "http://demo_content.tagdiv.com/Newspaper_6/city_news/rec-header.jpg");
td_demo_media::add_image_to_media_gallery('td_city_sidebar_ad',                 "http://demo_content.tagdiv.com/Newspaper_6/city_news/rec-sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_city_small_ad',                   "http://demo_content.tagdiv.com/Newspaper_6/city_news/rec-small.jpg");