<?php


td_demo_media::add_image_to_media_gallery('placeholder_2',            'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-placeholder-2.jpg');
td_demo_media::add_image_to_media_gallery('placeholder_3',            'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-placeholder-3.png');
td_demo_media::add_image_to_media_gallery('placeholder_4',            'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-placeholder-4.png');

//patterns
td_demo_media::add_image_to_media_gallery('pattern1',                 'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-pattern-bg1.jpg');