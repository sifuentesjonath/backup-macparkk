<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_pic_logo_white',          'http://demo_content.tagdiv.com/Newspaper_6/fashion/Logo-fashion-white.png');

//ads
td_demo_media::add_image_to_media_gallery('td_fashion_ad',              "http://demo_content.tagdiv.com/Newspaper_6/fashion/big_ad_fashion.jpg");
td_demo_media::add_image_to_media_gallery('td_fashion_sidebar_ad',      "http://demo_content.tagdiv.com/Newspaper_6/fashion/rec300.jpg");

