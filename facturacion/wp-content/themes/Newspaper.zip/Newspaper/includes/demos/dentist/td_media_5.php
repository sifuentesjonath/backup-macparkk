<?php

//logos
td_demo_media::add_image_to_media_gallery('3m',                                 "http://demo_content.tagdiv.com/Newspaper_multi/dentist/3m.png");
td_demo_media::add_image_to_media_gallery('bio',                                "http://demo_content.tagdiv.com/Newspaper_multi/dentist/bio.png");
td_demo_media::add_image_to_media_gallery('invisalign',                         "http://demo_content.tagdiv.com/Newspaper_multi/dentist/invisalign.png");
td_demo_media::add_image_to_media_gallery('opalescence',                        "http://demo_content.tagdiv.com/Newspaper_multi/dentist/opalescence.png");
td_demo_media::add_image_to_media_gallery('spident',                            "http://demo_content.tagdiv.com/Newspaper_multi/dentist/spident.png");
td_demo_media::add_image_to_media_gallery('strau',                              "http://demo_content.tagdiv.com/Newspaper_multi/dentist/strau.png");
td_demo_media::add_image_to_media_gallery('vita',                               "http://demo_content.tagdiv.com/Newspaper_multi/dentist/vita.png");

//bg images
td_demo_media::add_image_to_media_gallery('hands',                              "http://demo_content.tagdiv.com/Newspaper_multi/dentist/xxx_hands_xxx.jpg");
td_demo_media::add_image_to_media_gallery('video',                              "http://demo_content.tagdiv.com/Newspaper_multi/dentist/xxx_video_xxx.jpg");