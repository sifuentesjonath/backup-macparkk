<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/blog/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_avatar',              "http://demo_content.tagdiv.com/Newspaper_6/blog/avatar.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo_desktop',        'http://demo_content.tagdiv.com/Newspaper_6/blog/classic-blog-logo.png');
td_demo_media::add_image_to_media_gallery('td_pic_logo_footer',         'http://demo_content.tagdiv.com/Newspaper_6/blog/classic-blog-logo-footer.png');



