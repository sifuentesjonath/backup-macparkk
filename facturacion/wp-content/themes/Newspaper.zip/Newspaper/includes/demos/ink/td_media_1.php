<?php
/**
 * Created by ra on 5/14/2015.
 */

//logo
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_multi/ink/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      'http://demo_content.tagdiv.com/Newspaper_multi/ink/logo-header@2x.png');
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             'http://demo_content.tagdiv.com/Newspaper_multi/ink/logo-mobile.png');

//hero
td_demo_media::add_image_to_media_gallery('hero_home',                  'http://demo_content.tagdiv.com/Newspaper_multi/ink/hero_home.jpg');