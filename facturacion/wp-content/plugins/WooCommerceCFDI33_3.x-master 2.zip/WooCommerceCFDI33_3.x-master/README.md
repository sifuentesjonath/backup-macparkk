# WooCommerceCFDI33_3.x

Woocommerce es una herramienta muy sencilla e intuitiva que
permite montar una tienda en línea con una amplia variedad de
funcionalidades que junto con otros plugins complementan las
operaciones básicas de ecommerce.

El plugin de Factura.com proporciona integración con la platafor-
ma de Factura.com incluyendo las siguientes funciones:

- Reporte de Facturas enviadas y canceladas en el panel de administración.
- Enviar facturas por email a los clientes automáticamente y cancelar facturas
desde el panel de administración.
- Funcionalidad para que los clientes creen facturas directamente desde el área
de clientes.
Reportes de historial de facturas y pedidos pendientes de facturar.
